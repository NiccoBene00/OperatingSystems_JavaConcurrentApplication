/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appello19062024;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Nicco
 */
public class Appello19062024 {

    /**
     * N.B = il codice che compare su carta e non nel programma è stato denotato dai commenti
     * "Error", mentre le parti di codice aggiunte sono denotate dai commenti
     * "Edit"
     */
    public static void main(String[] args) throws InterruptedException {
        int NA = 4;
        int L = 10;
        int N = 6;
        int K = 5;

        ArrayGenerator generator = new ArrayGenerator();
        ResourceManager rm = new ResourceManager(NA);
        ResultQueue rq = new ResultQueue(L);

        ProcessorThread[] pt = new ProcessorThread[N];
        for (int i = 0; i < pt.length; i++) {
            pt[i] = new ProcessorThread(generator, rm, rq, (int) (300 + Math.random() * 700), (int) (500 + Math.random() * 1500), K);
            pt[i].setName("Th-Processor_" + (i + 1));
            pt[i].start();

        }

        OutputThread[] ot = new OutputThread[2];
        for (int i = 0; i < ot.length; i++) {
            ot[i] = new OutputThread(rq, (int) (1000 + Math.random() * 1500));
            ot[i].setName("Th-Out_" + (i + 1));
            ot[i].start();
        }

        Thread.sleep(10000);

        System.out.println("\n");
        for (ProcessorThread p : pt) {
            p.interrupt();
        }

        for (OutputThread o : ot) {
            o.interrupt();
        }

        System.out.println("\n");
        for (ProcessorThread p : pt) {
            p.join();
            System.out.println(p.getName() + " has processed: " + p.arrayProcessed + " array");
        }

        for (OutputThread o : ot) {
            o.join();
            System.out.println(o.getName() + " has printed for: " + o.nPrint + " times");
        }

        //----------Edit--------------
        rm.releaseAllOccupied();
        //----------------------------

        System.out.println("\n");
        System.out.println("TOTAL ARRAYS GENERATED: " + generator.getNArray() + " | AVAILABLE RESOURCES: " + rm.getAvailableRes()
                + " | RESULTS NOT PRINTED (i.e. ENQUEUED): " + rq.getSize());
    }

}

class ArrayGenerator {

    private int[] array;
    private Semaphore mutex = new Semaphore(1);
    private int nArray = 0;

    public ArrayGenerator() {
    }

    public int[] getArray(int k) throws InterruptedException {
        mutex.acquire();
        
        //---------Error--------
        //if (nArray < k) {
        //----------------------
            array = new int[k];
            int index = 1;

            for (int i = 0; i < k; i++) {
                array[i] = nArray + index;
                index++;
            }

            nArray++;
        //}

        mutex.release();

        return array;
    }

    public int getNArray() {
        return nArray;
    }

}

class ResourceManager {

    private int NA;
    private int resourcesAvail = 0;
    private Semaphore mutex = new Semaphore(1);
    private Semaphore available;
    private Semaphore[] empty;

    public ResourceManager(int NA) {
        this.NA = NA;
        available = new Semaphore(this.NA);

        //----------Edit--------------
        empty = new Semaphore[this.NA];
        //----------------------------

        for (int i = 0; i < this.NA; i++) {
            empty[i] = new Semaphore(1);
            resourcesAvail++;
        }
    }

    public void getResources(int nRis) throws InterruptedException {
        available.acquire(nRis);
        mutex.acquire();

        for (int i = 0; i < nRis; i++) {
            empty[i].release();
        }

        resourcesAvail -= nRis;
        mutex.release();
    }

    public void releaseResources(int nRis) throws InterruptedException {
        mutex.acquire();

        for (int i = 0; i < nRis; i++) {
            empty[i].acquire();
        }

        resourcesAvail += nRis;
        mutex.release();
        available.release(nRis);
    }

    public int getAvailableRes() {
        return resourcesAvail;
    }

    //----------Edit--------------
    public void releaseAllOccupied() throws InterruptedException {
        int occupied = NA - resourcesAvail;
        for (int i = 0; i < occupied; i++) {
            empty[i].acquire();
        }
        available.release(occupied);
        resourcesAvail = NA;
    }
    //----------------------------
}

class Result {

    private int[] operands;
    private int result;

    public Result(int[] operands, int result) {
        this.operands = operands;
        this.result = result;
    }

    public int[] getOperands() {
        return operands;
    }

    public int getResult() {
        return result;
    }

    //----------Edit------------
    public String mytoString() {
        String s = "[";

        for (int i = 0; i < operands.length; i++) {
            if (i == operands.length - 1) {
                s = s + operands[i];
            } else {
                s = s + operands[i] + ",";
            }
        }

        s = s + "]";

        return s;
    }
    //--------------------------

}

class ResultQueue {

    private ArrayList<Result> results = new ArrayList<>();
    private int L;
    private Semaphore mutex = new Semaphore(1);
    private Semaphore empty;
    private Semaphore full = new Semaphore(0);

    public ResultQueue(int L) {
        this.L = L;
        empty = new Semaphore(L);
    }

    public void addResult(Result r) throws InterruptedException {
        empty.acquire();
        mutex.acquire();

        results.add(r);

        mutex.release();
        full.release();

    }

    public Result[] getResult() throws InterruptedException {
        full.acquire(2);
        mutex.acquire();

        Result[] r = new Result[2];
        r[0] = results.remove(0);
        r[1] = results.remove(0);

        mutex.release();
        empty.release(2);

        return r;

    }

    public int getSize() {
        return results.size();
    }

}

class ProcessorThread extends Thread {

    private ArrayGenerator generator;
    private ResourceManager rm;
    public int arrayProcessed = 0;
    private ResultQueue rq;
    private int T;
    private int TG;
    private int K;

    public ProcessorThread(ArrayGenerator generator, ResourceManager rm, ResultQueue rq, int T, int TG, int K) {
        this.generator = generator;
        this.rm = rm;
        this.rq = rq;
        this.T = T;
        this.TG = TG;
        this.K = K;
    }

    @Override
    public void run() {
        int nRis = 0;
        try {
            while (true) {
                nRis = (int) (Math.random() * 2);
                int[] array = new int[K];
                array = generator.getArray(K);
                sleep(TG);
                rm.getResources(nRis);
                int sum = 0;
                for (int i = 0; i < array.length; i++) {
                    sum += array[i];
                }

                arrayProcessed++;
                sleep(T);
                rm.releaseResources(nRis);
                Result r = new Result(array, sum);
                rq.addResult(r);
                System.out.println("[Available resources: " + rm.getAvailableRes() + "]");
            }

        } catch (InterruptedException ex) {
            System.out.println(getName() + " interrupted!");
        }
    }

}

class OutputThread extends Thread {

    private ResultQueue rq;
    public int nPrint = 0;
    private int X;

    public OutputThread(ResultQueue rq, int X) {
        this.rq = rq;
        this.X = X;
    }

    public void run() {
        try {

            while (true) {
                Result[] r = new Result[2];
                r = rq.getResult();

                System.out.println("First result: " + r[0].getResult() + " from array: " + r[0].mytoString()
                        + ", second result: " + r[1].getResult() + " from array: " + r[1].mytoString());

                nPrint++;
                sleep(X);
            }

        } catch (InterruptedException ex) {
            System.out.println(getName() + " interrupted!");
        }
    }

}
